<!--

function focusField(element, text) { //removes default text in search field
  if (element.value == text) {
	element.value = "";
  }
}

function blurField(element, text) { //removes default text in search field if left empty
  if (element.value == "") {
	element.value = text;
  }
}


function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);

// -->
